import asyncHandler from "express-async-handler";
import Chat from "../models/chatModels.js";
import User from "../models/userModel.js";
const accessChat = asyncHandler(async(req, res) => {
    const { userId } = req.body;

    if(!userId) {
        console.log("UserId param not sent with the request!");
        return res.sendStatus(400);
    }
    var isChat = await Chat.find({
        isRequest: false,
        $and: [
            {users: { $elemMatch: {$eq: req.user._id}}},
            {users: { $elemMatch: {$eq: userId}}}
        ],
    }).populate("users", "-password").populate("latestMessage");
    isChat = await User.populate(isChat, {
        path: 'latestMessage.sender',
        select: "name pic email",
    })

    if(isChat.length > 0){
        res.send(isChat[0])
    } else {
        var chatData = {
            chatName: "sender",
            isRequest: false,
            users: [req.user._id, userId],
        };
        try {
            const createdChat = await Chat.create(chatData);

            const FullChat = await Chat.findOne({_id: createdChat._id}).populate("users", "-password");

            res.status(200).send(FullChat);


        } catch (error) {
            res.status(400);
            throw new Error(error.message);
        }
    }
});

const fetchChat = asyncHandler(async(req,res) => {
    try {
        Chat.find({users: { $elemMatch: { $eq: req.user._id }} })
        .populate("users", "-password")
        .populate("latestMessage").sort({updatedAt: -1})
        .then(async (results) => {
            results = await User.populate(results, {
                path: "latestMessage.sender",
                select: "name email pic"
            });

            res.status(200).send(results);
        })
    } catch (error) {
        
    }
});

const requestChat = asyncHandler(async (req, res) => {
    const { userId } = req.body;
    var isReqChat = await Chat.find({
        isRequest: true,
        $and: [
            {users: { $elemMatch: {$eq: req.user._id}}},
            {users: { $elemMatch: {$eq: userId}}}
        ],
    }).populate("users", "-password").populate("latestMessage");
    isReqChat = await User.populate(isReqChat, {
        path: 'latestMessage.sender',
        select: "name pic email",
    });
    if(isReqChat.length > 0){
        res.send(isReqChat[0])
    } else {
        res.status(400).send("No Request Chats Found!");
    }
})
export { accessChat, fetchChat, requestChat };