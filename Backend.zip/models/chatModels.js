// chat name
// is request
// users
// latestMessage
import mongoose from "mongoose";

import { MongoClient } from "mongodb";
// var url = "mongodb+srv://admin:admin@cluster0.h4otjbn.mongodb.net/?retryWrites=true&w=majority";
// const db = "thirtyml";
// const client = new MongoClient(url);
// let conn;
// try{
//   conn = await client.connect();
//   // console.log("CONNECTION WAS SUCCESSFULL FROM BOOKING.JS");
// }catch(e){
//   console.error(e);
// }
// const database = client.db(db);

const chatModel = mongoose.model(
  "Chat",
mongoose.Schema({
  chatName:{
    type: String,
    trim: true,
  },
  isRequest: {  
        type: Boolean,
        default: false,
       },
  users: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
  }],
  latestMessage: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Message",
  },
},
{ timestamps: true }

),
"Chat"
);

export default chatModel;