import mongoose from "mongoose";

import { MongoClient } from "mongodb";
// var url = "mongodb+srv://admin:admin@cluster0.h4otjbn.mongodb.net/?retryWrites=true&w=majority";
// const db = "thirtyml";
// const client = new MongoClient(url);
// let conn;
// try{
//   conn = await client.connect();
//   // console.log("CONNECTION WAS SUCCESSFULL FROM BOOKING.JS");
// }catch(e){
//   console.error(e);
// }
// const database = client.db(db);

const messageModel = mongoose.model(
  "Message",
mongoose.Schema({
  sender:{
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },
  content: {  
        type: String,
        trim: true
       },
  chat: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Chat",
  }
},
{ timestamps: true }

),
"Message"
);

export default messageModel;