import express from "express";
import dotenv from "dotenv";
import connectDB from './config/db.js';
import userRoutes from './routes/userRoutes.js';
import chatRoutes from './routes/chatRoutes.js';
import errorHandler from "./middleware/errorHandler.js";
dotenv.config();

connectDB();;
const app = express();

app.use(errorHandler);

app.use(express.json());
app.get("/", (req, res) => {
    res.send("API IS RUNNING...");
});

app.use('/api/user', userRoutes);
app.use('/api/chat', chatRoutes);
app.get("/check", (_, res) => res.status(200).send("hi"));
const PORT = process.env.PORT || 5005;
app.listen(process.env.PORT,console.log("PORT :",PORT));
