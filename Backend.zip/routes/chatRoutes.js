import express from "express";
import verifyToken from "../middleware/authMiddlerware.js";
import { accessChat, fetchChat, requestChat } from "../controllers/chatController.js"
const router = express.Router();

router.route('/').post(verifyToken, accessChat);
router.route('/').get(verifyToken, fetchChat);
router.route('/req').post(verifyToken, requestChat);

export default router;