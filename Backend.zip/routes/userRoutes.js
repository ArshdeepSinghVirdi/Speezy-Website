import express from "express";
import { registerUser, authUser, allUser } from "../controllers/userController.js";
import verifyToken from "../middleware/authMiddlerware.js";
const router = express.Router()

router.route('/').post(registerUser).get(verifyToken ,allUser);
router.post('/login', authUser)

export default router;