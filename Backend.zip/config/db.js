import mongoose from "mongoose";

const connectDB = async () => {
  try {
    const DB = await mongoose.connect("mongodb+srv://eshllerdev:1WI2VbVILXodcBXo@cluster0.gz052mb.mongodb.net", {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      dbName: process.env.DB_NAME,
    });
    console.log(`MongoDB connected at ${DB.connection.host}`);
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
};

export default connectDB;
