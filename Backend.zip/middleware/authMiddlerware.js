import jwt from "jsonwebtoken";
import User from "../models/userModel.js"
import asyncHandler from "express-async-handler";

const verifyToken = asyncHandler(async(req, res, next) => {
    let token;
    // console.log("Ah shit here we go again!",req.headers.authorization);
    if( req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
        try {
            token = req.headers.authorization.split(" ")[1];

            // console.log("HERE IS THE TOKEN: ", token);
            const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

            req.user = await User.findById(decodedToken.id).select("-password");

            next();
        } catch (error) {
            res.status(401);
            throw new Error("Not authorized");
        }
    }

    if(!token) {
        res.status(401);
        throw new Error("Token not available!");
    }
});

export default verifyToken;