import React, { useEffect } from 'react'
import { Container, Box, TabList, Tab, Tabs, TabPanels, TabPanel } from "@chakra-ui/react";
import Login from '../components/Authentication/Login';
import Signup from '../components/Authentication/Signup';
import { useNavigate } from "react-router-dom";
const LoginPage = () => {

  const navigate = useNavigate();
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('userInfo'));

    if(user) navigate('/chats');
  }, [navigate])
  
  return (
    <Container maxW='xl' centerContent>
      <Box padding='4' bg='#FFF' color='black' w="100%" m="40px 0 15px 0" borderRadius="lg" borderWidth={1}>
        <Tabs variant='soft-rounded' colorScheme='yellow'>
          <TabList mb="1em">
            <Tab width="50%">Login</Tab>
            <Tab width="50%">Sign Up</Tab>
          </TabList>
          <TabPanels>
            <TabPanel>
              <Login />
            </TabPanel>
            <TabPanel>
              <Signup />
            </TabPanel>
          </TabPanels>
        </Tabs>
      </Box>
    </Container>
  )
}

export default LoginPage