import React from "react";
import { ChatState } from "../Context/ChatProvider";
import { Box, Container } from "@chakra-ui/react";
import SideDrawer from "../components/miscellaneous/SideDrawer.js";
import Feed from "../components/Feed";
import DashProfile from "../components/DashProfile";

const Dashboard = () => {
  const { user } = ChatState();
  console.log("USER :", user);
  return (
    <div style={{ width: "100%" }}>
      {user && <SideDrawer />}
      <Container maxW="8xl" centerContent >
        <Box
          display="flex"
          justifyContent="space-between"
          w="100%"
          h="91.5vh"
          // p="10px"
        >
          <Box width={{ base: "100%", md: "65%" }}>
            <Feed />
          </Box>
          <Box
            display={{ base: 'none',  md:'block'}}          
            width={{ base: "100%", md: "35%" }}
            sx={{ overflow: 'scroll'}}
            >
                <DashProfile />
          </Box>
        </Box>
      </Container>
    </div>
  );
};

export default Dashboard;
