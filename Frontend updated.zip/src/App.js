import { Route, Routes } from "react-router-dom";
import LoginPage from "./Pages/LoginPage";
import ChatPage from "./Pages/ChatPage";
import './App.css';
import Dashboard from "./Pages/Dashboard";
import LandingPage from "./Pages/LandingPage";
import Shortlist from "./Pages/Shortlist";
function App() {
  return (
    <div className="App">
      {/* <BrowserRouter> */}
        <Routes>
        <Route path="/">
            <Route index element={<LandingPage />} exact />
            <Route path="/login" element={<LoginPage />} exact />
            <Route path="chats" element={<ChatPage />} />
            <Route path="dashboard" element={<Dashboard />}></Route>
            <Route path="shortlist" element={<Shortlist />}></Route>
        </Route>
        </Routes>
      {/* </BrowserRouter> */}
    </div>
  );
}

export default App;
