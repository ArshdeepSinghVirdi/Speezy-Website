import React, { useEffect, useState } from 'react'
import { ChatState } from '../Context/ChatProvider'
import { Avatar, Box, Container, HStack, Stack, Text, VStack, useToast } from '@chakra-ui/react';
import axios from "axios";
import { getSender } from './config/ChatLogic';
const MyChats = ({fetchAgain}) => {

  const [loggedUser, setLoggedUser] = useState()
  const { selectedChat, setSelectedChat, user, chats, setChats } = ChatState();

  const toast = useToast();
  const fetchChats = async () => {
    try {
      const config = {
        headers: {
          Authorization: `Bearer ${user.token}`,
        }
      };

      const { data  } = await axios.get("/api/chat", config);
      setChats(data);
    } catch (error) {
      console.log(error)
      toast({
        title: "Error Occured!",
        description: "Failed to Load chats!",
        status: "warning",
        duration: 5000,
        isClosable: true,
        position: "bottom-left",
      });
    }
  };

  useEffect(() => {
    setLoggedUser(JSON.parse(localStorage.getItem("userInfo")));
    fetchChats();
    setSelectedChat(" ")
  }, [fetchAgain])
  console.log("isSelected?", selectedChat);
  return (
    // <Container maxW="8xl">
    <Box
    display= {{ base: selectedChat ? "none" : "flex", md: "flex" }}
    flexDir="column"
    alignItems="center"
    p={3}
    bg="white"
    width={{ base: "100%", md:"35%" }}
    borderRadius="lg"
    borderWidth="1px"
    borderTop="0"
    >
      <Box
        pb={3}
        px={3}
        fontSize={{ base: "28px", md: "30px" }}
        fontFamily="Titillium Web"
        dislpay="flex"
        w="100%"
        justifyContent="space-between"
        alignItems="center"
      >
        My Chats
      </Box>
      <Box
        display="flex"
        flexDir="column"
        p={3}
        w="100%"
        h="100%"
        borderRadius="lg"
        borderWidth="1px"
        borderTop="0"
        overFlowY="hidden"
      > 
      {chats ? (
        <Stack overflowY="scroll">
          {chats.map((chat) => (
            <Box
            onClick={setSelectedChat(chat)}
            cursor="pointer"
            bg={selectedChat === chat ? "yellow" : "black"}
            color = {selectedChat === chat ? "black" : "white"}
            px={3}
            py={2}
            borderTop="0"
            key={chat._id}
            minHeight="80px"
            display="flex"
            alignContent="center"
            >
              <HStack spacing='24px'
              >
                <Box w='40px' h='40px' >
                <Avatar
                      size={'sm'}
                      src={user.pic}
                    />
                </Box>
                <Box
                  display= {{ base: selectedChat ? "none" : "flex", md: "flex" }}
                  flexDir="column"
                  alignItems="start"
                  p={3}
                  width={{ base: "100%"}}
                  borderRadius="lg"
                  borderWidth="1px"
                  borderTop="0"
                  >
                  <Text fontFamily="Titillium Web" fontWeight="600">
                    {chat.chatName}
                  </Text>
                  <HStack>
                  <Text fontFamily="Titillium Web" fontWeight="300" fontSize="sm">
                    Let&apos;s meet in the middle... 20k?
                  </Text>
                  <Text fontSize="8px">
                    POKEMON
                  </Text>
                  </HStack>
                </Box>
              </HStack>
              {/* <Text>
                {!chat.isRequest ? getSender(loggedUser, chat.users) : chat.chatName}
              </Text> */}

            </Box>
          ))}
        </Stack>

      ) : (
        <> ChatLoading </>
      )}
      </Box>
    </Box>
    // </Container>
  )
}

export default MyChats