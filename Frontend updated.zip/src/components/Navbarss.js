import { ReactNode, useState } from 'react';
import {
  Box,
  Flex,
  Avatar,
  HStack,
  Link,
  IconButton,
  Button,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  MenuDivider,
  useDisclosure,
  useColorModeValue,
  Stack,
  Tabs,
  TabList,
  Tab,
  Container,
} from '@chakra-ui/react';
import MyChats from './MyChats.js';
import { HamburgerIcon, CloseIcon, BellIcon, ChevronDownIcon } from '@chakra-ui/icons';
import { useNavigate } from 'react-router-dom';

const Links = ['Dashboard', 'Inbox', 'Shortlist', 'Profile'];

const NavLink = ({ children }) => (
  <Link
    px={2}
    py={1}
    rounded={"md"}
    _hover={{
      textDecoration: "none",
      bg: useColorModeValue("gray.200", "gray.700")
    }}
    href={"#"}
  >
    {children}
  </Link>
)

export default function Navbarss() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [selectedChat, setSelectedChat] = useState(false);

  const navigate = useNavigate();

  const logoutHandler = () => {
    localStorage.removeItem("userInfo");
    navigate("/");
  }

  return (
    <>
      <Box bg="#FFF" px={4}> {/* bg={useColorModeValue('gray.100', 'gray.900')} */}
        <Flex h={16} alignItems={'center'} justifyContent={'space-around'}>
          <IconButton
            size={'md'}
            icon={isOpen ? <CloseIcon /> : <HamburgerIcon />}
            aria-label={'Open Menu'}
            display={{ md: 'none' }}
            onClick={isOpen ? onClose : onOpen}
          />
          <HStack spacing={8} alignItems={'center'} justifyContent="space-between">
            <Box>
              <img src="./logo.png" alt="" />
            </Box>
            {/* <HStack
              as={'nav'}
              spacing={4}
              display={{ base: 'none', md: 'flex' }}
              justifyContent="space-between"
              >
              {Links.map((link) => (
                <NavLink key={link}>{link}</NavLink>
              ))}
            </HStack> */}
          </HStack>
            <Box
            display={{ base: 'none', md: 'flex' }}
            justifyContent="space-evenly"
            alignItems="center"
            w="50%"
        >
            <Tabs colorScheme='black'>
                <TabList>
                    <Tab width="25%">Dashboard</Tab>
                    <Tab width="25%">Inbox</Tab>
                    <Tab width="25%">Shortlist</Tab>
                    <Tab width="25%">Profile</Tab>
                </TabList>

                {/* <TabPanels>
                    <TabPanel>
                    <p>one!</p>
                    </TabPanel>
                    <TabPanel>
                    <p>two!</p>
                    </TabPanel>
                    <TabPanel>
                    <p>three!</p>
                    </TabPanel>
                    <TabPanel>
                    <p>three!</p>
                    </TabPanel>
                </TabPanels> */}
                </Tabs>
        </Box>
          <Flex alignItems={'center'}>
            <Menu>
              <MenuButton
                as={Button}
                rounded={'full'}
                minW={0}
                bg="transparent"
                >
                <BellIcon fontSize="2xl" />
              </MenuButton>
              <MenuButton as={Button} bg="transparent">
                <i className="fa fa-ellipsis-h" aria-hidden="true"></i>
            </MenuButton>
              <MenuList>
                <MenuItem  onClick={logoutHandler}>Logout</MenuItem>
                <MenuItem>Link 2</MenuItem>
                <MenuDivider />
                <MenuItem>Link 3</MenuItem>
              </MenuList>
            </Menu>
          </Flex>
        </Flex>

        {isOpen ? (
          <Box pb={4} display={{ md: 'none' }}>
            <Stack as={'nav'} spacing={4}>
              {Links.map((link) => (
                <NavLink key={link}>{link}</NavLink>
              ))}
            </Stack>
          </Box>
        ) : null}
      </Box>

      <Container maxW='container.lg'>
        <Box
          display= {{ base: selectedChat ? "none" : "flex", md: "flex" }}
          flexDir="column"
          alignItems="center"
          p={3}
          bg="white"
          width={{ base: "100%", md:"31%" }}
          borderRadius="lg"
          borderWidth="1px"
          borderTop="0"
        >
        <Box
          pb={3}
          px={3}
          fontSize={{ base: "28px", md: "30px" }}
          fontFamily="Titillium Web"
          dislpay="flex"
          w="100%"
          justifyContent="space-between"
          alignItems="center"
        >POKEMON
        </Box>
        <Box
          display="flex"
          flexDir="column"
          p={3}
          w="100%"
          h="100%"
          borderRadius="lg"
          borderWidth="1px"
          borderTop="0"
          overFlowY="hidden"
        > 
        POKMON
        </Box>
        </Box>

      </Container>
    </>
  );
}