import React, { useEffect, useState } from "react";
import { ChatState } from "../Context/ChatProvider";
import {
  Box,
  Button,
  Input,
  InputGroup,
  InputRightElement,
  Text,
  useToast,
} from "@chakra-ui/react";
import { Search2Icon } from "@chakra-ui/icons";
import FeedCard from "./FeedCard";
const Feed = () => {
  const [loggedUser, setLoggedUser] = useState();
  const { user } = ChatState();

  const toast = useToast();

  useEffect(() => {
    setLoggedUser(JSON.parse(localStorage.getItem("userInfo")));
  }, []);
  return (
    <Box
      // display= {{ base: selectedChat ? "none" : "flex", md: "flex" }}
      flexDir="column"
      alignItems="center"
      p={3}
      // bg="white"
      borderRadius="lg"
    //   borderWidth="1px"
      borderTop="0"
    >
      <InputGroup size="md" bg="white" borderRadius="15px">
        <Input
          borderRadius="15px"
          pr="4.5rem"
          type='text'
          placeholder="Search for Brands, Events or Creators"
        />
        <InputRightElement width="4.5rem">
          <Button size="sm" bg="white">
            <Search2Icon />
          </Button>
        </InputRightElement>
      </InputGroup>
      <Box
        marginTop="8"
        p="5px"
        // border="2px solid"
      >
        <Text color="#8B8B8B" sx={{ fontWeight: '600'}} mb={7}>Your Feed</Text>
        <FeedCard />
      </Box>
    </Box>
  );
};

export default Feed;
