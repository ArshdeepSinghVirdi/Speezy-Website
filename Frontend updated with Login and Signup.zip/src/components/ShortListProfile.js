import { Avatar, Box, Button, HStack, Image, Text, VStack } from "@chakra-ui/react";
import React from "react";
import { AddIcon } from "@chakra-ui/icons";
import { AiFillInstagram } from "react-icons/ai";
import List from "./List";
import FeedCard from "./FeedCard";
const ShortListProfile = () => {
  return (
    <Box py={3} width="100%" >
      {/* <VStack> */}
        <Box width="100%">
            <FeedCard />
        </Box>
        {/* <Box width="100%" border="2px solid black"> */}

        {/* </Box> */}
        {/* <Box width="100%" border="2px solid black"> */}

        {/* </Box> */}
      {/* </VStack> */}
    </Box>
  );
};

export default ShortListProfile;
