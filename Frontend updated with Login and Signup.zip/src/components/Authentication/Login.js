// import { Button, FormControl, FormLabel, Input, InputGroup, InputRightElement, VStack, useToast } from '@chakra-ui/react';
// import React, { useState } from 'react';
// import axios from "axios";
// import { useNavigate } from "react-router-dom";

// const Login = () => {

//     const [show, setShow] = useState(false);
//     const [email, setEmail] = useState();
//     const [password, setPassword] = useState();
//     const [loading, setLoading] = useState(false);

//     const toast = useToast();
//     const navigate = useNavigate();
//     const handleClick = () => setShow(!show);

//     const submitHandler  = async () => {
//         setLoading(true);
//         if( !email || !password ) {
//             toast({
//                 title= "Please Fill All The Fields!",
//                 status= "warning",
//                 duration= 5000,
//                 isClosable= true,
//                 position= "bottom",
//             });
//             setLoading(false);
//             return;
//         }
//         try {
//             const config = {
//                 headers= {
//                     "Content-Type"= "application/json"
//                 }
//             };
//             const { data } = await axios.post("/api/user/login", {
//                 email,
//                 password
//             }, config
//             );
//             toast({
//                 title= "Login Successful",
//                 status= "success",
//                 duration= 5000,
//                 isClosable= true,
//                 position= "bottom",
//             });

//             localStorage.setItem("userInfo", JSON.stringify(data));

//             setLoading(false);
//             navigate('/chats')
//         } catch (error) {
//             console.log(error);
//             toast({
//                 title= "Error Occured",
//                 description= error.response.data.message,
//                 status= "warning",
//                 duration= 5000,
//                 isClosable= true,
//                 position= "bottom",
//             });
//             setLoading(false);
//         }

//     }
//   return (
//      <VStack spacing='5px' color="black">
//         <FormControl id='email' isRequired>
//             <FormLabel>Email</FormLabel>
//             <Input
//                 placeholder='Enter your Email'
//                 onChange={(e) => {setEmail(e.target.value)}}
//             ></Input>
//         </FormControl>
//         <FormControl id='password' isRequired>
//             <FormLabel>Password</FormLabel>
//             <InputGroup>
//                 <Input
//                     type={ show ? "text" = "password" }
//                     placeholder='Enter Password'
//                     onChange={(e) => {setPassword(e.target.value)}}
//                 />
//                 <InputRightElement width="4.5rem">
//                     <Button h="1.75rem" size="sm" onClick={handleClick}>
//                         { show ? "Hide" = "Show" }
//                     </Button>
//                 </InputRightElement>
//             </InputGroup>
//         </FormControl>
//         <Button
//             colorScheme='yellow'
//             width="100%"
//             marginTop={15}
//             onClick = {submitHandler}
//             isLoading={loading}
//         >
//             Login
//         </Button>
//     </VStack>
//   )
// }

// export default Login

import {
  Button,
  Container,
  Image,
  Box,
  Flex,
  Text,
  Progress,
  ButtonGroup,
  FormControl,
  GridItem,
  FormLabel,
  Input,
  InputGroup,
  InputRightElement,
  RadioGroup,
  Stack,
  Radio,
  HStack,
} from "@chakra-ui/react";
import React, { useState } from "react";
import { useToast } from "@chakra-ui/react";
import SpeezyBrands from "../../assets/Images/SpeezyBrands.png";
import SpeezyLogo from "../../assets/Images/SpeezyLogo.png";
import { InfoOutlineIcon, SearchIcon } from "@chakra-ui/icons";

const Form1 = () => {
  const [show, setShow] = useState(false);
  const handleClick = () => setShow(!show);
  const [selectedValue, setSelectedValue] = useState("");

  const handleRadioChange = (value) => {
    setSelectedValue(value);
  };
  return (
    <>
      <Text
        width="100%"
        maxH="30px"
        whiteSpace="nowrap"
        color="#3A3A3A"
        fontFamily="Cabinet Grotesk Variable"
        fontSize="24px"
        fontStyle="normal"
        fontWeight="800"
        lineHeight="normal"
        textAlign="center"
        mt="3.5%"
      >
        SIGN UP AS BRAND
      </Text>
      <Flex>
        <FormControl mr="12%" ml="12%" mt="5%">
          <Input id="Your-Name" placeholder="Name of Brand*" />
        </FormControl>
      </Flex>
      <Flex>
        <FormControl mt="5%" mr="12%" ml="12%">
          <Input id="role" type="role" placeholder="Type of Brand*" />
        </FormControl>
      </Flex>
      <Flex>
        <FormControl mt="5%" mr="12%" ml="12%">
          <Input
            id="email"
            type="email"
            placeholder="Geographic Sector (if applicable)"
          />
        </FormControl>
      </Flex>
      <Flex justifyContent="center">
        <Text
          mt="5%"
          mr="26%"
          width="304px"
          height="24px"
          color="#000000"
          fontFamily="Titillium Web"
          fontSize="16px"
          fontStyle="normal"
          fontWeight="400"
          lineHeight="normal"
        >
          Do your operations differ from other regions?
        </Text>
        {/* <InfoOutlineIcon ml="2%"/> */}
      </Flex>
      <Flex justifyContent="center">
        <RadioGroup
          onChange={handleRadioChange}
          value={selectedValue}
          mt="5%"
          mr="58%"
        >
          <Stack direction="row">
            <Radio value="yes">
              <Text
                color="#000000"
                fontfamily="Titillium Web"
                fontSize="16px"
                fontStyle="normal"
                fontWeight="600"
                lineHeight="normal"
              >
                Yes{" "}
              </Text>
            </Radio>
            <Radio value="no">
              {" "}
              <Text
                color="#000000"
                fontfamily="Titillium Web"
                fontSize="16px"
                fontStyle="normal"
                fontWeight="600"
                lineHeight="normal"
              >
                No{" "}
              </Text>
            </Radio>
          </Stack>
        </RadioGroup>
      </Flex>
    </>
  );
};

const Form2 = () => {
  return (
    <>
      <Text
        width="100%"
        maxH="30px"
        whiteSpace="nowrap"
        color="#3A3A3A"
        fontFamily="Cabinet Grotesk Variable"
        fontSize="24px"
        fontStyle="normal"
        fontWeight="800"
        lineHeight="normal"
        textAlign="center"
        mb="3.5%"
      >
        SIGN UP AS BRAND
      </Text>
      <Text
        width="100%"
        maxH="42px"
        whiteSpace="nowrap"
        color="#808080"
        fontFamily="Titillium Web"
        fontSize="14px"
        fontStyle="normal"
        fontWeight="400"
        lineHeight="normal"
        textAlign="center"
        mb="3.5%"
      >
        {" "}
        <Text as="span" color="#1F1F1F" fontWeight="600">
          Note:{" "}
        </Text>{" "}
        This information is confidential and solely for Speezy’s reference.
        <br />
        It will only be shared with a collaborator once the deal is finalized.
      </Text>
      <Flex>
        <FormControl mr="12%" ml="12%">
          <Input id="Your-Name" placeholder="Your name*" />
        </FormControl>
      </Flex>
      <Flex>
        <FormControl mt="5%" mr="12%" ml="12%">
          <Input id="role" type="role" placeholder="Your Role*" />
        </FormControl>
      </Flex>
      <Flex>
        <FormControl mt="5%" mr="12%" ml="12%">
          <Input id="email" type="email" placeholder="Your Company Email ID*" />
        </FormControl>
      </Flex>
      <Flex>
        <FormControl mt="5%" mr="12%" ml="12%">
          <Input id="Contact" type="Contact" placeholder="Contact*" />
        </FormControl>
      </Flex>
    </>
  );
};

const Form3 = () => {
  return (
    <>
      <Text
        width="100%"
        maxH="30px"
        whiteSpace="nowrap"
        color="#3A3A3A"
        fontFamily="Cabinet Grotesk Variable"
        fontSize="24px"
        fontStyle="normal"
        fontWeight="800"
        lineHeight="normal"
        textAlign="center"
        mb="3.5%"
      >
        SIGN UP AS BRAND
      </Text>
      <Flex>
        <Text
          mt="1%"
          ml="9.3%"
          width="115px"
          height="24px"
          color="#8B8B8B"
          fontFamily="Titillium Web"
          fontSize="16px"
          fontStyle="normal"
          fontWeight="400"
          lineHeight="normal"
        >
          Your Preferences
        </Text>
      </Flex>
      <HStack spacing={2} mt={2} ml="9%">
        <Button
          bg="#FFFADE"
          borderRadius="15px"
          border="2px solid #FFB800"
          width="163px"
          height="38px"
        >
          Food & Beverages{" "}
        </Button>
        <Button
          bg="#FFFADE"
          borderRadius="15px"
          border="2px solid #FFB800"
          width="107px"
          height="38px"
        >
          Education
        </Button>
      </HStack>
      <Flex>
        <FormControl mt="3%" mr="17%" ml="9%">
          <InputGroup>
            <Input
              id="search"
              type="search"
              placeholder="Search for types of Events or Creators"
              borderRadius="xl"
            />
            <InputRightElement pointerEvents="none">
              <SearchIcon color="#8B8B8B" width="20.546px" height="20.546px" />
            </InputRightElement>
          </InputGroup>
        </FormControl>
      </Flex>
    </>
  );
};

const Login = () => {
  const toast = useToast();
  const [step, setStep] = useState(1);
  const [progress, setProgress] = useState(33.33);
  const [activeStep, setActiveStep] = useState(0);

  const handleNext = () => {
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handlePrev = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  return (
    <>
      <Container maxW="100%" bg="#181818" centerContent direction="column">
        <Flex width="100vw" height="100vh">
          <Box flex="1" bg="#181818" p={4}>
            <Box
              maxW="118.152px"
              maxH="66px"
              width="100%"
              height="100%"
              mt="4%"
              ml="20%"
            >
              <Image src={SpeezyLogo} alt="logo" />
            </Box>
            <Box maxW="575px" maxH="224px" ml="20%">
              <Text
                color="#FFFFFF"
                fontFamily="Cabinet Grotesk Variable"
                fontSize="46px"
                fontStyle="normal"
                fontWeight="800"
                lineHeight="50px"
                letterSpacing="-0.69px"
              >
                Connect with events and creators that match{" "}
                <Text as="span" color="#FECD1E">
                  your brand’s{" "}
                </Text>{" "}
                audience and marketing goals!
              </Text>
            </Box>
            <Box ml="37%" overflow="hidden" mt="3%">
              <Image
                src={SpeezyBrands}
                alt="Image"
                maxW="569px"
                maxH="350px"
                overflow="hidden"
              />
            </Box>
          </Box>
          <Box
            flex="1"
            bg="#FFFFFF"
            p={4}
            borderWidth="1px"
            rounded="2xl"
            shadow="1px 1px 3px rgba(0,0,0,0.3)"
            maxWidth="694px"
            maxH="850px"
            mt="4%"
            mb="5%"
            mr="3%"
            as="form"
          >
            <Progress
              hasStripe
              value={progress}
              mb="5%"
              mx="5%"
              mt="3%"
              isAnimated
            ></Progress>
            {step === 1 ? <Form1 /> : step === 2 ? <Form2 /> : <Form3 />}
            <Flex w="100%" justifyContent="flex-end">
              <Flex mr="11.3%">
                {/* <Button
                    onClick={() => {
                      setStep(step - 1);
                      setProgress(progress - 33.33);
                    }}
                    isDisabled={step === 1}
                    colorScheme="teal"
                    variant="solid"
                    w="7rem"
                    mr="5%"
                  >
                    Back
                  </Button> */}
                <Button
                  isDisabled={step === 3}
                  onClick={() => {
                    setStep(step + 1);
                    if (step === 3) {
                      setProgress(100);
                    } else {
                      setProgress(progress + 33.33);
                    }
                  }}
                  width="150px"
                  height="42px"
                  bg="#212121"
                  borderRadius="9.349px"
                  boxShadow="1.6998553276062012px 1.6998553276062012px 6.799421310424805px 0px rgba(0, 0, 0, 0.09)"
                  mt="25%"
                >
                  <Text
                    color="#FFF"
                    fontFamily="Titillium Web"
                    fontSize="16px"
                    fontStyle="normal"
                    fontWeight="700"
                    lineHeight="normal"
                  >
                    Next
                  </Text>
                </Button>
              </Flex>
              {step === 3 ? (
                <Button
                width="150px"
                height="42px"
                bg="#212121"
                borderRadius="9.349px"
                boxShadow="1.6998553276062012px 1.6998553276062012px 6.799421310424805px 0px rgba(0, 0, 0, 0.09)"
                mt="25%"
                  onClick={() => {
                    toast({
                      title: "Account created.",
                      description: "We've created your account for you.",
                      status: "success",
                      duration: 3000,
                      isClosable: true,
                    });
                  }}
                >
                    <Text
                    color="#FFF"
                    fontFamily="Titillium Web"
                    fontSize="16px"
                    fontStyle="normal"
                    fontWeight="700"
                    lineHeight="normal"
                  >
                  Create My Account
                  </Text>
                </Button>
              ) : null}
            </Flex>
          </Box>
        </Flex>
      </Container>
    </>
  );
};

export default Login;
