// import { Button, FormControl, FormLabel, Input, InputGroup, InputRightElement, VStack } from '@chakra-ui/react';
// import React, { useState } from 'react';
// import { useToast } from '@chakra-ui/react';
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// const Signup = () => {
//     const toast = useToast()
//     const [name, setName] = useState();
//     const [show, setShow] = useState(false);
//     const [email, setEmail] = useState();
//     const [password, setPassword] = useState();
//     const [confirmPassword, setConfirmPassword] = useState();
//     const [pic, setPic] = useState();
//     const [loading, setLoading] = useState(false);
//     const navigate = useNavigate();
//     const handleClick = () => setShow(!show);

//     const postDetails  = (pics) => {
//         setLoading(true);
//         if(pics === undefined) {
//             toast({
//                 title= "Please Select an Image!",
//                 status= "warning",
//                 duration= 5000,
//                 isClosable= true,
//                 position= "bottom",
//             });
//             return;
//         }
//         if(pics.type === "image/jpeg" || pics.type === "image/png") {
//             const data = new FormData();
//             data.append("file", pics);
//             data.append("upload_preset", "speezy");
//             data.append("cloud_name", "dlwaf1irk");
//             fetch("https=//api.cloudinary.com/v1_1/dlwaf1irk/image/upload", {
//                 method= "POST",
//                 body= data
//             }).then((res) => res.json())
//             .then(data => {
//                 // console.log(data);
//                 setPic(data.url.toString());
//                 setLoading(false);
//             })
//             .catch((err) => {
//                 console.log(err);
//                 setLoading(false);
//             });
//         } else {
//             toast({
//                 title= "Please Select an Image!",
//                 status= "warning",
//                 duration= 5000,
//                 isClosable= true,
//                 position= "bottom",
//             })
//         }
//     }
//     const submitHandler  = async () => {
//         setLoading(true);
//         if(!name || !email || !password || !confirmPassword) {
//             toast({
//                 title= "Please Fill All The Fields!",
//                 status= "warning",
//                 duration= 5000,
//                 isClosable= true,
//                 position= "bottom",
//             });
//             setLoading(false);
//             return;
//         }
//         if(password !== confirmPassword) {
//             toast({
//                 title= "Passwords Do Not Match",
//                 status= "warning",
//                 duration= 5000,
//                 isClosable= true,
//                 position= "bottom",
//             });
//             setLoading(false);
//             return;
//         }
//         try {
//             const config = {
//                 headers= {
//                     "Content-Type"= "application/json"
//                 }
//             };
//             const { data } = await axios.post("/api/user", {
//                 name,
//                 email,
//                 password,
//                 pic
//             }, config
//             );
//             toast({
//                 title= "Registration Successful",
//                 status= "success",
//                 duration= 5000,
//                 isClosable= true,
//                 position= "bottom",
//             });

//             localStorage.setItem("userInfo", JSON.stringify(data));

//             setLoading(false);
//             navigate('/chats')
//         } catch (error) {
//             console.log(error);
//             toast({
//                 title= "Error Occured",
//                 description= error.response.data.message,
//                 status= "warning",
//                 duration= 5000,
//                 isClosable= true,
//                 position= "bottom",
//             });
//             setLoading(false);
//         }

//     }
//   return (
//      <VStack spacing='5px' color="black">
//         <FormControl id='first-name' isRequired>
//             <FormLabel>Name</FormLabel>
//             <Input
//                 placeholder='Enter your name'
//                 onChange={(e) => {setName(e.target.value)}}
//             ></Input>
//         </FormControl>
//         <FormControl id='email' isRequired>
//             <FormLabel>Email</FormLabel>
//             <Input
//                 placeholder='Enter your Email'
//                 onChange={(e) => {setEmail(e.target.value)}}
//             ></Input>
//         </FormControl>
//         <FormControl id='password' isRequired>
//             <FormLabel>Password</FormLabel>
//             <InputGroup>
//                 <Input
//                     type={ show ? "text" = "password" }
//                     placeholder='Enter Password'
//                     onChange={(e) => {setPassword(e.target.value)}}
//                 />
//                 <InputRightElement width="4.5rem">
//                     <Button h="1.75rem" size="sm" onClick={handleClick}>
//                         { show ? "Hide" = "Show" }
//                     </Button>
//                 </InputRightElement>
//             </InputGroup>
//         </FormControl>
//         <FormControl id='confirm-password' isRequired>
//             <FormLabel>Confirm Password</FormLabel>
//             <InputGroup>
//                 <Input
//                     type={ show ? "text" = "password" }
//                     placeholder='Confirm Password'
//                     onChange={(e) => {setConfirmPassword(e.target.value)}}
//                 />
//                 <InputRightElement width="4.5rem">
//                     <Button h="1.75rem" size="sm" onClick={handleClick}>
//                         { show ? "Hide" = "Show" }
//                     </Button>
//                 </InputRightElement>
//             </InputGroup>
//         </FormControl>
//         <FormControl id='pic' isRequired>
//             <FormLabel>Upload your Picture</FormLabel>
//             <Input
//                 type="file"
//                 p={1.5}
//                 accept="image/*"
//                 onChange={(e) => postDetails(e.target.files[0])}
//             ></Input>
//         </FormControl>
//         <Button
//             colorScheme='yellow'
//             width="100%"
//             marginTop={15}
//             onClick = {submitHandler}
//             isLoading={loading}
//         >
//             Sign Up
//         </Button>
//     </VStack>
//   )
// }

// export default Signup

import {
  Button,
  Divider,
  Container,
  Image,
  Box,
  Flex,
  Text,
  Spacer,
} from "@chakra-ui/react";
import React from "react";
import SpeezyLogo from "../../assets/Images/SpeezyLogo.png";
import Vector from "../../assets/Images/Vector.png";
import Group from "../../assets/Images/Group.png";
import Group363 from "../../assets/Images/Group 363.png";
import ZigzagL from "../../assets/Images/ZigzagL.png";
import ZigzagR from "../../assets/Images/ZigzagR.png";

const Signup = () => {
  return (
    <Container maxW="100%" bg="#181818" centerContent direction='column'>
      <Box maxW="118.152px" maxH="58.99px" width='100%' height='100%' mt={7}>
        <Image src={SpeezyLogo} alt="logo" />
      </Box>
      <Flex alignItems="center" justifyContent="center" mt={5}>
        <Divider width="481px" height="2px" bg="rgba(255, 255, 255, 0.25)" />
        <Text
          color="#FFFFFF"
          textAlign="center"
          fontFamily="Cabinet Grotesk Variable"
          fontSize="20px"
          fontStyle="normal"
          fontWeight="500"
          lineHeight="normal"
          letterSpacing="0.4px"
          width="189px"
        >
          SIGN UP AS
        </Text>
        <Divider width="481px" height="2px" bg="rgba(255, 255, 255, 0.25)" />
      </Flex>
      <Flex
        justifyContent="space-between"
        alignItems="center"
        mt={6}
        bg="#181818"
        ml="11%"
        direction='column'
      >
        <Flex justifyContent="center" mt={7} gap="138"  overflow='auto'>
          <Image
            src={Vector}
            alt="Image 1"
            m={1}
            p={1}
            width="76.144px"
            height="89.998px"
          />
          <Spacer />
          <Image
            src={Group}
            alt="Image 2"
            m={1}
            p={1}
            width="74.021px"
            height="77.998px"
          />
          <Spacer />
          <Image
            src={Group363}
            alt="Image 3"
            m={1}
            p={1}
            width="84px"
            height="84px"
          />
          <Spacer />
        </Flex>
      </Flex>
      <Flex
        justifyContent="space-between"
        alignItems="center"
        bg="#181818"
        ml="1%"
        gap="10"
        overflowY='auto'
      >
        {/* First Card */}
        <Box
          textAlign="center"
          width="338px"
          height="213px"
          flexShrink="0"
          rounded="lg"
        >
          <Box
            w="338px"
            p={4}
            height="200px"
            bg="#181818"
            boxShadow="md"
            mt={2}
            borderRadius="20px"
            rounded="lg"
            background="#1F1F1F"
          >
            <Text
              color="#FFFFFF"
              textAlign="center"
              alignItems="center"
              fontFamily="Cabinet Grotesk Variable"
              fontSize="24px"
              fontStyle="normal"
              fontWeight="800"
              lineWeight="63.874px"
              letterSpacing="0.48px"
              width="105px"
              height="64px"
              ml="32%"
              mt="5%"
              whiteSpace="nowrap"
            >
              A BRAND
            </Text>
            <Text
              color="#979797"
              textAlign="center"
              fontFamily="Cabinet Grotesk Variable"
              fontSize="20px"
              fontStyle="normal"
              fontWeight="500"
              lineWeight="32.874px"
              letterSpacing="0.4px"
              width="271px"
              height="66px"
              ml="5%"
              mt="2.5%"
            >
              Find Events & Creators to <br /> collaborate with
            </Text>
          </Box>
        </Box>

        {/* Second Card */}
        <Box
          textAlign="center"
          width="338px"
          height="213px"
          flexShrink="0"
          rounded="lg"
        >
          <Box
            w="338px"
            p={4}
            height="200px"
            bg="#181818"
            boxShadow="md"
            mt={2}
            borderRadius="20px"
            rounded="lg"
            background="#1F1F1F"
          >
            <Text
              color="#FFFFFF"
              textAlign="center"
              alignItems="center"
              fontFamily="Cabinet Grotesk Variable"
              fontSize="24px"
              fontStyle="normal"
              fontWeight="800"
              lineWeight="63.874px"
              letterSpacing="0.48px"
              width="113px"
              height="64px"
              ml="28%"
              mt="5%"
              whiteSpace="nowrap"
            >
              AN EVENT
            </Text>
            <Text
              color="#979797"
              textAlign="center"
              fontFamily="Cabinet Grotesk Variable"
              fontSize="20px"
              fontStyle="normal"
              fontWeight="500"
              lineWeight="32.874px"
              letterSpacing="0.4px"
              width="271px"
              height="66px"
              ml="5%"
              mt="2.5%"
            >
              Find Sponsors, Brands & <br />
              Creators to collaborate with
            </Text>
          </Box>
        </Box>

        {/* Third Card */}
        <Box
          textAlign="center"
          width="338px"
          height="213px"
          flexShrink="0"
          rounded="lg"
        >
          <Box
            w="338px"
            p={4}
            height="200px"
            bg="#181818"
            boxShadow="md"
            mt={2}
            borderRadius="20px"
            rounded="lg"
            background="#1F1F1F"
          >
            <Text
              color="#FFFFFF"
              textAlign="center"
              alignItems="center"
              fontFamily="Cabinet Grotesk Variable"
              fontSize="24px"
              fontStyle="normal"
              fontWeight="800"
              lineWeight="63.874px"
              letterSpacing="0.48px"
              width="143px"
              height="64px"
              ml="25%"
              mt="5%"
              whiteSpace="nowrap"
            >
              A CREATOR
            </Text>
            <Text
              color="#979797"
              textAlign="center"
              fontFamily="Cabinet Grotesk Variable"
              fontSize="20px"
              fontStyle="normal"
              fontWeight="500"
              lineWeight="32.874px"
              letterSpacing="0.4px"
              width="271px"
              height="66px"
              ml="5%"
              mt="2.5%"
            >
              Find Sponsors & Brands
              <br /> to collaborate with
            </Text>
          </Box>
        </Box>
      </Flex>
      <Button
        bg=""
        borderRadius="10px"
        border="1.3px solid rgba(255, 255, 255, 0.40)"
        px={6}
        py={3}
        mt={8}
        width="150px"
        height="42px"
        ml="1%"
        hover={{ bgcolor: "black" }}
      >
        <Text
          color="rgba(255, 255, 255, 0.40)"
          textAlign="center"
          leadingTrim="both"
          textEdge="cap"
          fontFamily="Titillium Web"
          fontSize="16px"
          fontStyle="normal"
          fontWeight="600"
          lineHeight="normal"
        >
          Next
        </Text>
      </Button>
      <Flex gap="195" overflow='hidden' >
        <Image src={ZigzagL} alt="Image1" width='100%' maxW="1111.665px" height="100px" />
        <Spacer />
        <Image
          src={ZigzagR}
          alt="Image2"
          width='100%'
          maxW="1111.665px"
          height="100px"
          ml="18%"
        />
        <Spacer />
      </Flex>
       
    </Container>
  );
};

export default Signup;
