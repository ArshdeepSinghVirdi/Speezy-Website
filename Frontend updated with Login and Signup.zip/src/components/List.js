import { Avatar, Box, Button, Divider, HStack, Text, VStack } from "@chakra-ui/react";
import React from "react";
import { list } from '../utilies/data';
const List = () => {
  return (
    <Box>
      <VStack>
        <Box width="100%">
            {list.map((item) => (
                <>
                <HStack justifyContent="space-between">
                  <HStack>
                    <Box>
                      <Avatar src={item.img} />
                    </Box>
                    <VStack alignItems="start" gap={0} alignContent="space-around">
                      <Text sx={{ fontWeight: "600" }}>{item.name}</Text>
                      <Text color="#6F6F6F">{item.msg}</Text>
                    </VStack>
                  </HStack>
                  <Box>
                    <Button bg="#FFEE94" borderRadius="15px">
                      {item.btnText}
                    </Button>
                  </Box>
                </HStack>
              <Divider my={4} />
              </>
            ))}
        </Box>
      </VStack>
    </Box>
  );
};

export default List;
