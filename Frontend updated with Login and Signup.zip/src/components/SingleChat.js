import React from 'react'
import { ChatState } from '../Context/ChatProvider'
import { Box, IconButton, Text } from '@chakra-ui/react';
import { ArrowBackIcon } from '@chakra-ui/icons';

const SingleChat = ({ fetchAgain, setFetchAgain }) => {

    const { user, selectedChat, setSelectedChat } = ChatState();
    // console.log("SELECYED: CHAT",selectedChat);
  return (
    <div>
        { selectedChat ? (
        <>
        <Text
            fontSize={{ base: "28px", md:"30px" }}
            pb={3}
            px={2}
            w="100%"
            fontFamily="Titillium Web"
            d="flex"
            justifyContent={{ base: "space-between" }}
            alignItems="center"
        >
            <IconButton
                display={{ base: "flex", md: "none" }}
                icon={<ArrowBackIcon />}
                onClick={() => setSelectedChat("")}
            />
        </Text>
        </>) : (
            <Box
                d="flex"
                alignItems="center"
                justifyContent="center"
                h="100%"
            >
                <Text
                    fontSize="3xl"
                    pb={3}
                    fontFamily="Titillium Web"
                >Click on the user to start chatting</Text>
            </Box>
        )}
    </div>
  )
}

export default SingleChat