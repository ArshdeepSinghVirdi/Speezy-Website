import { Avatar, Box, Button, ButtonGroup, Container, HStack, Image, Text, VStack } from '@chakra-ui/react'
import React from 'react'
import { AiFillInstagram } from "react-icons/ai";
import { Icon } from '@chakra-ui/react'
const FeedCard = () => {
  return (
    <Box width="100%">
        <VStack gap={0}>
            <Box>
                <Image src="/feed_banner.png" alt="Banner Image"></Image>
            </Box>
            <Box bg="white" borderRadius="0px 0px 15px 15px" width="100%" sx={{paddingBottom: '10px'}}>
                <HStack justifyContent="space-between">
                    <HStack paddingLeft="5px">
                        <div><Avatar name='Dan Abrahmov' src='https://bit.ly/dan-abramov' /></div>
                        <div>
                            <div style={{ display: 'flex', alignItems: 'center'}}><Text fontSize={{ base: 'xs', md:'sm', lg:'lg'}} as='b' sx={{ margin: '12px'}}>Mood Indigo Sponsors 2020</Text><Text color="#8B8B8B" sx={{ fontWeight:"600"}}>College Festival</Text></div>
                            <Button size={{md: 'md', sm: 'sm', base: 'xs'}} bg="white" sx={{ border:  '1.5px solid #FFB800', borderRadius: '15px'}}><Icon sx={{ margin: '2px'}} as={AiFillInstagram}/> Mood Indigo</Button>
                        </div>
                    </HStack>
                    {/* <div>Looking For <span className='chips'>Food & Beverage</span> <span className='chips'>Lifestyle</span> <span className='chips'>Beauty</span> <span className='chips'>Fashion</span> <span className='chips'>+3</span></div> */}
                    <Box
                    display="flex"
                    >
                        <div>
                            <Text color="#A0A0A0" fontSize={{ base: 'xs', md:'sm', lg:'md'}} sx={{ fontWeight: '600' }}>Looking For</Text>
                        </div>
                        <div>
                            <Button size={{md: 'md', sm: 'sm', base: 'xs'}} bg="#ECECEC" borderRadius="15px" m="1">Food...</Button>
                            <Button size={{md: 'md', sm: 'sm', base: 'xs'}} bg="#ECECEC" borderRadius="15px" m="1">Lifestyle</Button>
                            <Button size={{md: 'md', sm: 'sm', base: 'xs'}} bg="#ECECEC" borderRadius="15px" m="1">Bea...</Button>
                            <Button size={{md: 'md', sm: 'sm', base: 'xs'}} bg="#ECECEC" borderRadius="15px" m="1">Fashion</Button>
                            <Button size={{md: 'md', sm: 'sm', base: 'xs'}} bg="#ECECEC" borderRadius="15px" m="1">+3</Button>
                        </div>
                    </Box>
                </HStack>
            </Box>
        </VStack>
    </Box>
  )
}

export default FeedCard