import React, { useEffect, useState } from "react";
import { ChatState } from "../Context/ChatProvider";
import {
  Box,
  Button,
  Input,
  InputGroup,
  InputRightElement,
  Text,
  useToast,
} from "@chakra-ui/react";
import { Search2Icon } from "@chakra-ui/icons";
import FeedCard from "./FeedCard";
const Shortlist_Feed = () => {
  const [loggedUser, setLoggedUser] = useState();
  const { user } = ChatState();

  const toast = useToast();

  useEffect(() => {
    setLoggedUser(JSON.parse(localStorage.getItem("userInfo")));
  }, []);
  return (
    <Box
      // display= {{ base: selectedChat ? "none" : "flex", md: "flex" }}
      flexDir="column"
      alignItems="center"
      p={3}
      // bg="white"
      borderRadius="lg"
    //   borderWidth="1px"
      borderTop="0"
    >

      <Box
        // marginTop="8"
        p="5px"
        // border="2px solid"
      >
        {/* <Text color="#8B8B8B" sx={{ fontWeight: '600'}} mb={7}>Your Feed</Text> */}
        <FeedCard />
      </Box>
    </Box>
  );
};

export default Shortlist_Feed;
