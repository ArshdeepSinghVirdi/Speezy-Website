import { Avatar, Box, Button, HStack, Text, VStack } from "@chakra-ui/react";
import React from "react";
import { AddIcon } from "@chakra-ui/icons";
import { AiFillInstagram } from "react-icons/ai";
import List from "./List";
const DashProfile = () => {
  return (
    <Box py={3} width="100%" >
      <VStack>
        <Box width="100%">
          <Box bg="white" border="0.7px solid #C9C9C9" borderRadius="16px">
            <Box bg="#EEE" borderRadius="16px 16px 0px 0px">
              &nbsp; <br />
              <br />
              <br />
            </Box>
            <VStack p="15px" pt="0">
              <Avatar
                size="xl"
                src="https://bit.ly/dan-abramov"
                sx={{
                  position: "relative",
                  bottom: "50px",
                  marginBottom: "-50px",
                }}
                alt="pokemon"
              />
              <Text as="b">Coca-Cola</Text>
              <Text>Brand</Text>
              <HStack width="100%" justifyContent="center" mb={3}>
                <Button borderRadius="15px">
                  <AiFillInstagram />
                  nidhi_sharma
                </Button>
                <Button borderRadius="15px">
                  <AiFillInstagram />
                  nidhi_sharma
                </Button>
                <Button borderRadius="15px">
                  <AiFillInstagram />
                  nidhi_sharma
                </Button>
              </HStack>
              <Button
                bg="black"
                color="white"
                w="100%"
                colorScheme="blackAlpha"
              >
                <Button colorScheme="blackAlpha" bg="black" color="white">
                  <AddIcon />
                </Button>{" "}
                Create New Campaign
              </Button>
            </VStack>
          </Box>
        </Box>
        <Box width="100%">
          <Box
            bg="white"
            border="0.7px solid #C9C9C9"
            borderRadius="16px"
            py={3}
            px={5}
          >
            <HStack justifyContent="space-between" mb={4}>
              <Text sx={{ fontWeight: "600" }} color="#8B8B8B">
                Recent Conversations
              </Text>
              <Text sx={{ fontWeight: "600" }} color="black">
                Go to Inbox &gt;
              </Text>
            </HStack>
            <List />
          </Box>
        </Box>
      </VStack>
    </Box>
  );
};

export default DashProfile;
