import React from "react";
import { ChatState } from "../Context/ChatProvider";
import { Box, Button, Container, HStack, Image, Input, InputGroup, InputRightElement, Text } from "@chakra-ui/react";
import SideDrawer from "../components/miscellaneous/SideDrawer.js";
import ShortlistFeed from "../components/Shortlist_Feed";
import ShortListProfile from "../components/ShortListProfile";
import { Search2Icon } from "@chakra-ui/icons";

const Shortlist = () => {
  const { user } = ChatState();
  console.log("USER :", user);
  return (
    <div style={{ width: "100%" }}>
      {user && <SideDrawer />}
      <Container maxW="8xl" centerContent >
      <InputGroup size="md" bg="white" borderRadius="15px" marginTop="8">
        <Input
          borderRadius="15px"
          pr="4.5rem"
          type='text'
          placeholder="Search for Brands, Events or Creators"
        />
        <InputRightElement width="4.5rem">
          <Button size="sm" bg="white">
            <Search2Icon />
          </Button>
        </InputRightElement>
      </InputGroup>
      <HStack justifyContent="space-between" alignItems="center" gap={5} width="100%" marginTop={5} p={3}>
                <div>
                <Text color="#B1B1B1" sx={{ fontWeight: '600'}} >Shortlisted items</Text>
                </div>
                <div style={{ display: 'flex', textAlign: 'end'}}>
                    <div style={{ display: 'flex', alignItems: 'center'}}>
                    <Image src="/sort_icon.svg" alt="" height="0.86381rem" width="1.07975rem"  sx={{ marginRight: '7px'}}/>
                    Sort By
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center'}}>
                    <Image src="/filter.svg" alt="" width="0.96869rem" height="0.96869rem" sx={{ marginRight: '7px'}} />
                    Filters
                    </div>
                </div>
            </HStack>
        <Box
          display="flex"
          justifyContent="space-between"
          w="100%"
          h="91.5vh"
          // p="10px"
        >
          <Box width={{ base: "100%", md: "65%" }}>
            <ShortlistFeed />
          </Box>
          <Box
            display={{ base: 'none',  md:'block'}}          
            width={{ base: "100%", md: "35%" }}
            sx={{ overflow: 'scroll'}}
            >
                <ShortListProfile />
          </Box>
        </Box>
      </Container>
    </div>
  );
};

export default Shortlist;
