export const list = [
    { img: 'https://bit.ly/dan-abramov', name: 'Rahul Choudhary', msg: 'When will it be ready?', btnText: 'Amount Finalized'},
    { img: 'https://bit.ly/dan-abramov', name: 'Kailash Chaurasia', msg: 'Received?', btnText: 'Payment Initiated'},
    { img: 'https://bit.ly/dan-abramov', name: 'Shalini Jain', msg: 'Received', btnText: 'Deal Completed'},
    { img: 'https://bit.ly/dan-abramov', name: 'Navjot Kaur', msg: 'Great service.', btnText: 'Payment Completed'},
    { img: 'https://bit.ly/dan-abramov', name: 'Mamta Lodhi', msg: 'Ok', btnText: 'Discussing Deal'}
]