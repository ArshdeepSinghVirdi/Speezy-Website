import { Avatar, Box, Button, Container, Drawer, DrawerBody, DrawerContent, DrawerHeader, DrawerOverlay, Flex, HStack, IconButton, Input, MenuDivider, Spinner, Stack, Tab, TabList, TabPanel, TabPanels, Tabs, Text, Tooltip, useColorModeValue, useDisclosure, useToast } from '@chakra-ui/react';
import React, { useState } from 'react'
import {
    Menu,
    MenuButton,
    MenuList,
    MenuItem,
    // MenuItemOption,
    // MenuGroup,
    // MenuOptionGroup,
    // MenuDivider
  } from '@chakra-ui/react';
import { HamburgerIcon, CloseIcon, BellIcon, ChevronDownIcon } from '@chakra-ui/icons';
import { ChatState } from '../../Context/ChatProvider';
import { Link, useNavigate } from 'react-router-dom';
import axios from "axios";
import ChatLoading from '../ChatLoading';
import UserListItem from '../UserAvatar/UserListItem';

const Links = ['Dashboard', 'Inbox', 'Shortlist', 'Profile'];

const NavLink = ({ children }) => (
  <Link
    px={2}
    py={1}
    rounded={"md"}
    _hover={{
      textDecoration: "none",
      bg: useColorModeValue("gray.200", "gray.700")
    }}
    href={"#"}
  >
    {children}
  </Link>
)


const SideDrawer = () => {
    const { user, setSelectedChat, chats, setChats } = ChatState();
    const [search, setSearch] = useState("");
    const [searchResult, setSearchResult] = useState([]);
    const [loading, setLoading] = useState(false);
    const [loadingChat, setLoadingChat] = useState();
    const { isOpen, onOpen, onClose } = useDisclosure();
    const {
      isOpen: isDrawerOpen,
      onOpen: onDrawerOpen,
      onClose: onDrawerClose
    } = useDisclosure();
    const navigate = useNavigate();

    const logoutHandler = () => {
        localStorage.removeItem("userInfo");
        navigate("/");
    };
    const toast = useToast()
    const handleSearch = async() => {

      if(!search){
        toast({
          title: "Please enter something in the search",
          status: "warning",
          duration: 5000,
          isClosable: true,
          position: "top-left"
        });
        return;
      }

      try {
        setLoading(true);

        const config = {
          headers: {
            Authorization: `Bearer ${user.token}`
          }
        };

        const { data } = await axios.get(`/api/user?search=${search}`, config)

        setLoading(false);
        setSearchResult(data);
      } catch (error) {
        console.log(error);
      }
    };
    const accessChat = async (userId) => {
      try {
        setLoadingChat(true);

        const config = {
          headers: {
            "Content-type": "application/json",
            Authorization: `Bearer ${user.token}`,
          }
        };

        const { data } = await axios.post('/api/chat', {userId}, config);

        if(!chats.find((c) => c._id === data._id)){
          setChats([data, ...chats])
        }
        setSelectedChat(data);
        setLoadingChat(false);
        onClose();
      } catch (error) {
        console.log(error);
        
      }
    };
  return (
    <>
      <Box bg="#FFF" px={4}> {/* bg={useColorModeValue('gray.100', 'gray.900')} */}
        <Flex h={16} alignItems={'center'} justifyContent={'space-around'}>
          <IconButton
            size={'md'}
            icon={isOpen ? <CloseIcon /> : <HamburgerIcon />}
            aria-label={'Open Menu'}
            display={{ md: 'none' }}
            onClick={isOpen ? onClose : onOpen}
          />
          <HStack spacing={8} alignItems={'center'} justifyContent="space-between">
            <Box>
              <img src="./logo.png" alt="" />
            </Box>
            {/* <HStack
              as={'nav'}
              spacing={4}
              display={{ base: 'none', md: 'flex' }}
              justifyContent="space-between"
              >
              {Links.map((link) => (
                <NavLink key={link}>{link}</NavLink>
              ))}
            </HStack> */}
          </HStack>
            <Box
            display={{ base: 'none', md: 'flex' }}
            justifyContent="space-evenly"
            alignItems="center"
            w="50%"
        >
            <Tabs colorScheme='black'>
                <TabList>
                    <Tab width="25%">Dashboard</Tab>
                    <Tab width="25%">Inbox</Tab>
                    <Tab width="25%">Shortlist</Tab>
                    <Tab width="25%">Profile</Tab>
                </TabList>

                {/* <TabPanels>
                    <TabPanel>
                    <p>one!</p>
                    </TabPanel>
                    <TabPanel>
                    <p>two!</p>
                    </TabPanel>
                    <TabPanel>
                    <p>three!</p>
                    </TabPanel>
                    <TabPanel>
                    <p>three!</p>
                    </TabPanel>
                </TabPanels> */}
                </Tabs>
        </Box>
          <Flex alignItems={'center'}>
            <Menu>
              <MenuButton
                rounded={'full'}
                minW={0}
                bg="transparent"
                >
                <BellIcon fontSize="2xl" />
              </MenuButton>
              <MenuButton as={Button} bg="transparent">
                <i className="fa fa-ellipsis-h" aria-hidden="true"></i>
            </MenuButton>
              <MenuList>
                <MenuItem  onClick={logoutHandler}>Logout</MenuItem>
                <MenuItem>
                <Avatar size="sm" cursor="pointer" name={user.name} />
                {user.name}</MenuItem>
                <MenuDivider />
                <MenuItem>Link 3</MenuItem>
              </MenuList>
            </Menu>
            <Menu>
            <MenuButton onClick={onDrawerOpen}>
              Search
            </MenuButton>
            </Menu>
          </Flex>
        </Flex>

        {isOpen ? (
          <Box pb={4} display={{ md: 'none' }}>
            <Stack as={'nav'} spacing={4}>
              {Links.map((link) => (
                <NavLink key={link}>{link}</NavLink>
              ))}
            </Stack>
          </Box>
        ) : null}
      </Box>
      <Drawer placement='left' onClose={onDrawerClose} isOpen={isDrawerOpen}>
        <DrawerOverlay />
        <DrawerContent>
          <DrawerHeader borderBottomWidth="1px">Search Users</DrawerHeader>
          <DrawerBody>
            <Box display="flex" pb={2}>
              <Input
                placeholder="Search by name or email"
                mr={2}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <Button
                onClick={handleSearch}
              
              >Search
              </Button>
            </Box>
            {loading ? (
              <ChatLoading />
            ) : (
            searchResult?.map(user => (
              <UserListItem key={user._id} user={user} handleFunction={() => accessChat(user._id)} />
            ))
            
            )}
            {loadingChat && <Spinner ml="auto" d="flex" />}
          </DrawerBody>
        </DrawerContent>
      </Drawer>

      {/* <Container maxW='container.lg'>
        <Box
          display= {{ base: selectedChat ? "none" : "flex", md: "flex" }}
          flexDir="column"
          alignItems="center"
          p={3}
          bg="white"
          width={{ base: "100%", md:"31%" }}
          borderRadius="lg"
          borderWidth="1px"
          borderTop="0"
        >
        <Box
          pb={3}
          px={3}
          fontSize={{ base: "28px", md: "30px" }}
          fontFamily="Titillium Web"
          dislpay="flex"
          w="100%"
          justifyContent="space-between"
          alignItems="center"
        >POKEMON
        </Box>
        <Box
          display="flex"
          flexDir="column"
          p={3}
          w="100%"
          h="100%"
          borderRadius="lg"
          borderWidth="1px"
          borderTop="0"
          overFlowY="hidden"
        > 
        POKMON
        </Box>
        </Box>

      </Container> */}
    </>
  )
}

export default SideDrawer