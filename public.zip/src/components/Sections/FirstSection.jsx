import React from 'react'
import Image from 'mui-image'
import SpeezyLogo from '../Images/SpeezyLogo.png'
import MainSectionLogo from '../Images/MainPageImg.png'
import { Box, Button, Stack, Typography } from '@mui/material'
import VectorShade from '../Images/VectorMainPage.png'

const FirstSection = () => {
    return (
        <Stack sx={{ paddingX: { xs: '6%', md: '8%' }, bgcolor: '#181818', position: 'relative' }}>
            <Stack flexDirection='column' justifyContent='center' alignItems='center' gap='2vh' sx={{ paddingY: '6vh' }}>
                <Box sx={{ width: { xs: '30%', md: '12%' } }}>
                    <Image src={SpeezyLogo} alt='logo' />
                </Box>
                <Typography sx={{ color: '#FECD1E', textAlign: 'center', fontWeight: '850', fontFamily: 'Cabinet Grotesk', letterSpacing: '0px', fontSize: { xs: '6vw', md: '3vw' }, lineHeight: { xs: '4vh', md: '6.2vh' } }}
                >
                    Find and collaborate with the <br />perfect <span style={{ color: '#FFFFFF' }}> brands, events</span> and <span style={{ color: '#FFFFFF' }}> creators </span>
                </Typography>
                <Box sx={{ display: 'flex', justifyContent: 'center', width: 'fit-content', width: '100%', gap: { xs: '5%', md: '10px' }, mt: '3.5vh' }}>
                    <Button variant='contained' href='#' sx={{ textTransform: 'capitalize', bgcolor: '#282828', border: '1px solid #FFFFFF66', width: { xs: '48%', md: '14%' }, fontWeight: '500', fontSize: '80%', borderRadius: '8px', '&:hover': { bgcolor: '#FECD1E', border: '1px solid #FFFFFF66' } }}>Why Speezy</Button>

                    <Button variant='contained' href='#' sx={{ textAlign: 'center', color: '#000000', textTransform: 'capitalize', bgcolor: '#FFFFFF', border: '0.85px solid #D0D0D0', width: { xs: '48%', md: '14%' }, fontWeight: '500', fontSize: '80%', letterSpacing: '0.1px', borderRadius: '8px', '&:hover': { bgcolor: '#282828', color: '#FECD1E', border: '0.85px solid #D0D0D0' } }}>Sign Up for Speezy</Button>
                </Box>
                <Box sx={{ height: 'fit-content', width: { xs: '90%', md: '50%' }, mt: '2.5rem' }}>
                    <Image src={MainSectionLogo} alt='MainSectionLogo' />
                </Box>
            </Stack>
            <Box sx={{ width: '30%', position: 'absolute', right: 0, top: '35%' }}>
                <Image src={VectorShade} alt='zigzag' width='100%' height='100%' />
            </Box>
        </Stack>
    )
}

export default FirstSection
