import React from 'react'
import { Box, Button, Divider, Stack, Typography } from '@mui/material'
import Image from 'mui-image'
import SpeezyLogo from '../Images/SpeezyLogo.png'
import Eknoor from '../Images/Eknoor.png'
import Nandini from '../Images/Nandini.png'
import ZigZagR from '../Images/ZigzagR.png';
import ZigZagL from '../Images/ZigzagL.png';
import line from '../Images/Footerline.png'
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import InstagramIcon from '@mui/icons-material/Instagram';

const FourthSection = () => {
    return (
        <Stack sx={{ paddingX: { xs: '6%', md: '8%' }, paddingY: '5rem', mt: { xs: '10rem', md: '20rem' }, bgcolor: '#181818', position: 'relative' }}>
            <Stack direction='column'>
                <Stack direction='column' alignItems='center' sx={{ width: '100%' }}>
                    <Box component='img' src={ZigZagL} alt='zigzag' sx={{ position: 'absolute', left: '0px', top: '10%', width: '30%' }} />

                    <Box sx={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: { xs: '22px', md: '1rem' } }}>
                        <Typography sx={{ textTransform: 'uppercase', color: '#FFFFFF3B', lineHeight: '5px' }}>
                            The Future of Marketing is here
                        </Typography>
                        <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', color: 'white', textAlign: 'center' }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', fontWeight: '600', fontSize: { xs: '22px', md: '2rem' }, textAlign: 'center', whiteSpace: 'nowrap',fontFamily: 'Cabinet Grotesk' }}>
                                Join <Box component='img' src={SpeezyLogo} alt='logo' sx={{ width: { xs: '8rem', md: '9rem' } }} />and stay ahead of the curve
                            </Box>
                        </Box>
                        <Button variant='contained' href='#' sx={{ color: 'black', width: 'fit-content', textTransform: 'capitalize', bgcolor: '#FFFFFF', border: '0.85px solid #D0D0D0', fontWeight: '600', fontSize: '80%', letterSpacing: '0.1px', borderRadius: '8px', '&:hover': { bgcolor: '#FECD1E', border: '0.85px solid #D0D0D0' } }}>
                            Sign Up for Speezy
                        </Button>
                    </Box>
                    <Box component='img' src={ZigZagR} alt='zigzag' sx={{ position: 'absolute', right: '0px', width: '30%', top: '10%' }} />

                    <Stack direction={{ xs: 'column', sm: 'row' }} gap='2rem' mt='4rem'>
                        <Box sx={{ width: '14rem' }}>
                            <Image src={Eknoor} alt='ProfileImg' />
                        </Box>
                        <Box sx={{ width: '14rem' }}>
                            <Image src={Nandini} alt='ProfileImg' />
                        </Box>
                    </Stack>
                </Stack>
                <Box sx={{ mt: '5rem', mb: '4rem' }}>
                    <Image src={line} alt='line' />
                </Box>
                <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent='space-between' alignItems={{ xs: 'center', md: 'end' }} rowGap='1rem'>
                    <Stack direction='column' alignItems='start' justifyContent='end'>
                        <Typography sx={{ color: 'white', fontWeight: '400', fontSize: '125%',fontFamily: 'Cabinet Grotesk' }}>Contact us for any questions or assistance
                        </Typography>
                        <Box sx={{ display: 'flex', width: 'fit-content', width: '100%', gap: { xs: '5%', md: '8%' }, mt: '3.5vh' }}>
                            <Button variant='contained' href='#' sx={{ textTransform: 'capitalize', bgcolor: '#282828', border: '1px solid #FFFFFF66', px: '6%', width: { xs: '48%', md: 'fit-content' }, fontWeight: '500', fontSize: '80%', borderRadius: '8px', '&:hover': { bgcolor: '#FECD1E', border: '1px solid #FFFFFF66' } }}>Read FAQs</Button>

                            <Button variant='contained' href='#' sx={{ textAlign: 'center', color: '#000000', textTransform: 'capitalize', bgcolor: '#FFFFFF', border: '0.85px solid #D0D0D0', px: '6%', width: { xs: '48%', md: 'fit-content' }, fontWeight: '500', fontSize: '80%', letterSpacing: '0.1px', borderRadius: '8px', '&:hover': { bgcolor: '#FEC600', border: '0.85px solid #D0D0D0' } }}>Contact Us</Button>
                        </Box>
                    </Stack>
                    <Stack direction='row' gap='10%' alignContent='center' mt={{ xs: '15px', md: 0 }}>
                        <LinkedInIcon sx={{ color: 'white', fontSize: '30px' }} />
                        <InstagramIcon sx={{ color: 'white', fontSize: '30px' }} />
                    </Stack>
                </Stack>
            </Stack>
        </Stack>
    )
}

export default FourthSection
