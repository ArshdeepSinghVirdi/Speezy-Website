import React from 'react'
import Image from 'mui-image'
import SpeezyLogo from '../Images/SpeezyLogo.png'
import MainSectionLogo from '../Images/MainPageImg.png'
import { Box, Button, Stack, Typography } from '@mui/material'
import VectorShade from '../Images/VectorMainPage.png'
import DiversePool from '../Images/DiversePool.png';
import StreamlinedCom from '../Images/StreamlinedComm.png';
import BoostedROI from '../Images/BoostedRoi.png';
import CircleUp from '../Images/CircleUp.png';
import CircleDown from '../Images/CircleDown.png';
import ZigzagLeft from '../Images/ZigzagLeft.png';
import ZigzagRight from '../Images/ZigzagRight.png';
import SpeezyBrands from '../Images/SpeezyBrands.png';
import SpeezyEvents from '../Images/SpeezyEvents.png';
import SpeezyCreators from '../Images/SpeezyCreators.png';

const ThirdSection = () => {
    return (
        <Stack sx={{ paddingX: { xs: '6%', md: '8%' }, position: 'relative', paddingY: '4rem' }}>
            <Stack direction='column' justifyContent='center' gap={{ xs: '5rem', md: '10rem' }}>
                <Stack sx={{ position: 'relative' }}>
                    <Box component='img' src={CircleUp} alt='circle' sx={{ width: { xs: '30px', md: '80px' }, position: 'absolute', right: '5%' }} />
                    <Box sx={{ display: 'flex', flexDirection: 'column', textAlign: 'center', gap: '1.6rem' }}>
                        <Typography sx={{ fontSize: { xs: '18px', md: '100%' }, fontWeight: '700', color: '#FEC600',fontFamily: 'Cabinet Grotesk' }}>WHY SPEEZY?</Typography>
                        <Typography sx={{ fontSize: '150%', fontWeight: '400', lineHeight: { xs: '25px', md: 'unset' }, fontFamily: 'Cabinet Grotesk' }}>
                            Speezy <span style={{ fontWeight: '700' }}>simplifies the sponsorship process</span> and<br /> helps you <span style={{ fontWeight: '700' }}>reach your marketing goals</span> by providing
                        </Typography>
                    </Box>
                    <Box component='img' src={CircleDown} alt='circle' sx={{ width: '50px', position: 'absolute', top: { xs: '15%', md: '30%' }, left: '0px' }} />
                    <Stack direction={{ xs: 'column', md: 'row' }} justifyContent='space-between' gap='5%' rowGap='6vh' marginTop='5rem'>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: { xs: '10px', md: '2rem' } }}>
                            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                                <Image src={DiversePool} alt='Image' height='auto' width='14.5rem' />
                            </Box>
                            <Typography sx={{ fontWeight: { xs: '600', md: '400' }, fontSize: { xs: '16px', md: '100%' }, textAlign: 'center', width: { xs: '100%', md: '70%' }, mx: 'auto' }}>
                                <span style={{ fontWeight: '700' }}>Diverse pool</span> of brands, events, and creators to collaborate with.
                            </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: { xs: '10px', md: '2rem' } }}>
                            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                                <Image src={StreamlinedCom} alt='Image' height='auto' width='24rem' />
                            </Box>
                            <Typography sx={{ fontWeight: { xs: '600', md: '400' }, fontSize: { xs: '16px', md: '100%' }, textAlign: 'center', width: { xs: '100%', md: '60%' }, mx: 'auto' }}>
                                <span style={{ fontWeight: '700' }}>Streamlined communication</span> platform for sponsors and the sponsored.
                            </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: { xs: '10px', md: '2rem' } }}>
                            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                                <Image src={BoostedROI} alt='Image' height='auto' width='10.5rem' />
                            </Box>
                            <Typography sx={{ fontWeight: { xs: '600', md: '400' }, fontSize: { xs: '16px', md: '100%' }, textAlign: 'center', width: { xs: '100%', md: '90%' }, mx: 'auto' }}>
                                <span style={{ fontWeight: '700' }}>Boosted ROI margins</span> by reducing marketing costs and increasing revenue.
                            </Typography>
                        </Box>
                    </Stack>
                </Stack>
                <Stack direction='row'>
                    <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: { xs: 'center', md: 'start' }, gap: '1rem' }}>
                        <Typography sx={{ fontSize: '100%', fontWeight: '700', color: '#FEC600',fontFamily: 'Cabinet Grotesk' }}>SPEEZY FOR BRANDS</Typography>
                        <Typography sx={{ fontSize: '150%', fontWeight: '400',fontFamily: 'Cabinet Grotesk', width: { xs: '100%', md: '50%' } }}>
                            Connect with events and creators that <span style={{ fontWeight: '700' }}>match your target audience</span> and <span style={{ fontWeight: '700' }}>marketing goals!</span>
                        </Typography>
                        <Button variant='contained' href='#' sx={{ width: 'fit-content', textTransform: 'capitalize', bgcolor: '#212121', border: '0.85px solid #D0D0D0', fontWeight: '500', fontSize: '80%', letterSpacing: '0.1px', borderRadius: '8px', '&:hover': { bgcolor: '#212121', color: '#FEC600', border: '0.85px solid #D0D0D0' } }}>Sign Up for Speezy</Button>
                    </Box>
                    <Box sx={{ width: { xs: '60%', md: '40%' }, position: 'absolute', right: '0px', top: { xs: '64%', md: 'unset' } }}>
                        <Image src={SpeezyBrands} alt='Image' width='100%' height='100%' />
                    </Box>
                    <Box component='img' src={ZigzagLeft} alt='zigzag' sx={{ position: 'absolute', left: '0px', top: { xs: '30%', md: '50%' }, width: '35%' }} />
                </Stack>
                <Stack direction='row' justifyContent='flex-end' mt={{ xs: '12rem', md: '13rem' }}>
                    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'end', justifyContent: { xs: 'center', md: 'start' }, gap: '1rem' }}>
                        <Typography sx={{ fontSize: '100%', fontWeight: '700', color: '#FEC600',fontFamily: 'Cabinet Grotesk' }}>SPEEZY FOR EVENTS</Typography>
                        <Typography sx={{ fontSize: '150%', fontWeight: '400', width: { xs: '100%', md: '55%' }, textAlign: 'right',fontFamily: 'Cabinet Grotesk' }}>
                            Get access to a  <span style={{ fontWeight: '700' }}>wide range of brands</span> looking to sponsor events like yours.
                        </Typography>
                        <Button variant='contained' href='#' sx={{ width: 'fit-content', textTransform: 'capitalize', bgcolor: '#212121', border: '0.85px solid #D0D0D0', fontWeight: '500', fontSize: '80%', letterSpacing: '0.1px', borderRadius: '8px', '&:hover': { bgcolor: '#212121', color: '#FEC600', border: '0.85px solid #D0D0D0' } }}>Sign Up for Speezy</Button>
                    </Box>
                    <Box sx={{ width: { xs: '60%', md: '40%' }, position: 'absolute', left: '0px', top: { xs: '80%', md: 'unset' } }}>
                        <Image src={SpeezyEvents} alt='Image' width='100%' height='100%' />
                    </Box>
                    <Box component='img' src={ZigzagRight} alt='zigzag' sx={{ position: 'absolute', right: '0px', width: '35%', top: { xs: '72%', md: '76%' } }} />
                </Stack>
                <Stack direction='row' mt={{ xs: '12rem', md: '14rem' }}>
                    <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: { xs: 'center', md: 'start' }, gap: '1rem' }}>
                        <Typography sx={{ fontSize: '100%', fontWeight: '700', color: '#FEC600',fontFamily: 'Cabinet Grotesk' }}>SPEEZY FOR CREATORS</Typography>
                        <Typography sx={{ fontSize: '150%', fontWeight: '400', width: { xs: '100%', md: '55%' },fontFamily: 'Cabinet Grotesk' }}>
                            <span style={{ fontWeight: '700' }}>Elevate your influencer game </span> with Speezy's <span style={{ fontWeight: '700' }}>cutting-edge platform </span>or finding the <span style={{ fontWeight: '700' }}>perfect sponsor </span>
                        </Typography>
                        <Button variant='contained' href='#' sx={{ width: 'fit-content', textTransform: 'capitalize', bgcolor: '#212121', border: '0.85px solid #D0D0D0', fontWeight: '500', fontSize: '80%', letterSpacing: '0.1px', borderRadius: '8px', '&:hover': { bgcolor: '#212121', color: '#FEC600', border: '0.85px solid #D0D0D0' } }}>Sign Up for Speezy</Button>
                    </Box>
                    <Box sx={{ width: { xs: '60%', md: '40%' }, position: 'absolute', right: '0px', top: { xs: '98%', md: 'unset' } }}>
                        <Image src={SpeezyCreators} alt='Image' width='100%' height='100%' />
                    </Box>
                    <Box component='img' src={ZigzagLeft} alt='zigzag' sx={{ position: 'absolute', left: '0px', top: '100%', width: '35%' }} />
                </Stack>
            </Stack >
        </Stack >
    )
}

export default ThirdSection
