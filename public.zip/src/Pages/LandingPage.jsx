import FirstSection from './Pages/components/Sections/FirstSection.jsx'
import ThirdSection from './Pages/components/Sections/ThirdSection.jsx'
import FourthSection from './Pages/components/Sections/FourthSection.jsx'
import { Box, Button, ButtonBase, IconButton, Stack } from '@mui/material'
import Image from 'mui-image'
import React, { useState } from 'react'
import SiteLogo from '../Images/SpeezyLogo.png'
import MenuIcon from '@mui/icons-material/Menu';

const LandingPage = () => {
  const [openMenu, setOpenMenu] = useState(false);

  return (
    <Stack sx={{ position: 'relative' }}>
      <Box sx={{ paddingX: { xs: '6%', md: '8%' }, fontFamily: 'Roboto Mono, monospace', bgcolor: 'white', paddingY: '1vh', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: '0px', zIndex: 100, }}>
        <Box sx={{ width: { xs: '8rem', md: '12%' }, height: 'fit-content' }}>
          <Image src={SiteLogo} alt='MainLogo' />
        </Box>
        <Stack flexDirection='row' justifyContent='end' gap='3vw' sx={{ width: 'fit-content', display: { xs: 'none', md: 'flex' } }}>
          <ButtonBase disableRipple href='#' sx={{ fontFamily: 'Titillium Web, sans-serif', color: '#141414F', fontSize: '1.1vw', fontWeight: '600' }}>About Us</ButtonBase>
          <ButtonBase disableRipple href='#' sx={{ fontFamily: 'Titillium Web, sans-serif', color: '#141414F', fontSize: '1.1vw', fontWeight: '600' }}>Pricing</ButtonBase>
          <Button variant="contained" size='small' href='#' sx={{ fontFamily: 'Titillium Web, sans-serif', textTransform: 'capitalize', color: '#FFD15A', bgcolor: '#212121', borderRadius: '9px', paddingX: '20px', border: '0.85px solid #D0D0D0', fontSize: '1.1vw', fontWeight: '600', '&:hover': { bgcolor: '#FFD15A', color: '#212121' } }}>Sign Up</Button>
        </Stack>
        {/* .................For Mobile Screen..................... */}

        <IconButton onClick={() => { setOpenMenu(!openMenu) }} sx={{ display: { xs: 'flex', md: 'none' } }}>
          <MenuIcon sx={{ position: 'relative', fontSize: '120%' }} />
        </IconButton>
        <Stack flexDirection='column' justifyContent='center' alignItems='center' gap='8vw' sx={{
          position: 'absolute', left: 0, top: '100%', bgcolor: 'white', width: '100%', height: '15rem', zIndex: 5,
          display: `${openMenu ? 'flex' : 'none'}`,
        }}>
          <ButtonBase disableRipple href='#' onClick={() => { setOpenMenu(false) }} sx={{ color: '#141414F', fontSize: { xs: '18px', md: '1.1vw' }, fontWeight: '500' }}>About Us</ButtonBase>
          <ButtonBase disableRipple href='#' onClick={() => { setOpenMenu(false) }} sx={{ color: '#141414F', fontSize: { xs: '18px', md: '1.1vw' }, fontWeight: '500' }}>Pricing</ButtonBase>
          <Button variant="contained" size='small' href='#' onClick={() => { setOpenMenu(false) }} sx={{ width: 'fit-content', textTransform: 'capitalize', color: '#FFD15A', bgcolor: '#212121', borderRadius: '9px', paddingX: '20px', border: '0.85px solid #D0D0D0', fontSize: { xs: '18px', md: '1.1vw' }, fontWeight: '500', '&:hover': { bgcolor: '#212121' } }}>Sign Up</Button>
        </Stack>
      </Box>
      <FirstSection />
      <ThirdSection />
      <FourthSection />
    </Stack>
  )
}

export default LandingPage
