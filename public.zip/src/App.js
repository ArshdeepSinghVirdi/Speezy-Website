import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./Pages/Home";
import LandingPage from './Pages/LandingPage'
import ChatPage from "./Pages/ChatPage";
import './App.css';
function App() {
  return (
    <div className="App">
      {/* <BrowserRouter> */}
        <Routes>
        <Route path="/">
            <Route index element={<Home />} exact />
            <Route path="chats" element={<ChatPage />} />
        </Route>
        </Routes>
      {/* </BrowserRouter> */}
      <LandingPage/>
    </div>
  );
}

export default App;
